#!/bin/bash

java -jar student-database.jar --database database --keystore keys/web/keystore.jks --keystore-password changeit
